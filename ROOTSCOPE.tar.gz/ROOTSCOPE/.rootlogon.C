{
    //gSystem->Load("myROOTSCOPE_C.so");

}
